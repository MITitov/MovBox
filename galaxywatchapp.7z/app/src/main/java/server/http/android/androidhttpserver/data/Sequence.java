package server.http.android.androidhttpserver.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Sequence {
    @PrimaryKey(autoGenerate = true)
    private long id;

    private String userName;
    private String startDate;
    private long timestamp;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
