package server.http.android.androidhttpserver.data;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import static androidx.room.ForeignKey.CASCADE;

@Entity(foreignKeys = @ForeignKey(entity = Sequence.class,
        parentColumns = "id",
        childColumns = "seq_id",
        onDelete = CASCADE))
public class ACCData extends AbstractData {
    @PrimaryKey(autoGenerate = true)
    private long id;

    private long seq_id;

    private float x;
    private float y;
    private float z;
    private float magn;
    private float xn;
    private float yn;
    private float zn;

    public ACCData() {
    }

    public ACCData(long time, float x, float y, float z) {
        this.id = 0;
        this.x = x;
        this.y = y;
        this.z = z;
        this.timestamp = time;
        this.magn = (float) Math.sqrt(x * x + y * y + z * z);
        this.xn = x / this.magn;
        this.yn = y / this.magn;
        this.zn = z / this.magn;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getSeq_id() {
        return seq_id;
    }

    public void setSeq_id(long seq_id) {
        this.seq_id = seq_id;
    }

    public float getX() {
        return x;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float getY() {
        return y;
    }

    public void setY(float y) {
        this.y = y;
    }

    public float getZ() {
        return z;
    }

    public void setZ(float z) {
        this.z = z;
    }

    public float getMagn() {
        return magn;
    }

    public void setMagn(float magn) {
        this.magn = magn;
    }

    public float getXn() {
        return xn;
    }

    public void setXn(float xn) {
        this.xn = xn;
    }

    public float getYn() {
        return yn;
    }

    public void setYn(float yn) {
        this.yn = yn;
    }

    public float getZn() {
        return zn;
    }

    public void setZn(float zn) {
        this.zn = zn;
    }

    @Override
    public String toString() {
        return "ACCData{" +
                "id=" + id +
                ", seq_id=" + seq_id +
                ", x=" + x +
                ", y=" + y +
                ", z=" + z +
                ", magn=" + magn +
                ", xn=" + xn +
                ", yn=" + yn +
                ", zn=" + zn +
                ", timestamp=" + timestamp +
                '}';
    }
}
