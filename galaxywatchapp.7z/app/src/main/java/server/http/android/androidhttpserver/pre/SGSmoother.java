package server.http.android.androidhttpserver.pre;

import java.util.ArrayList;
import java.util.List;

import server.http.android.androidhttpserver.data.ACCData;
import server.http.android.androidhttpserver.data.GYROData;
import server.http.android.androidhttpserver.data.HRMData;

/**
 * 5-point 2-order Savitzky–Golay filter
 */
public class SGSmoother implements Smoother {

    //    @Override
    public List<HRMData> smoothHRM(List<HRMData> list) {
        List<HRMData> result = new ArrayList<>();
        List<Float> counts = new ArrayList<>();
        List<Float> temp = new ArrayList<>();
        for (HRMData p : list) {
            counts.add(p.getBpm());
        }
        smooth(counts, temp);
        for (int i = 0; i < list.size(); i++) {
            result.add(new HRMData(list.get(i).getTimestamp(), temp.get(i)));
        }
        return result;
    }

    @Override
    public List smoothAG(List list) {
        List result = new ArrayList<>();
        List<Float> counts = new ArrayList<>();
        List<Float> tempX = new ArrayList<>();
        List<Float> tempY = new ArrayList<>();
        List<Float> tempZ = new ArrayList<>();
        boolean acc = !(list.get(0) instanceof GYROData);
        for (Object p : list) {
            counts.add(acc ? ((ACCData) p).getX() : ((GYROData) p).getX());
        }
        smooth(counts, tempX);
        counts.clear();
        for (Object p : list) {
            counts.add(acc ? ((ACCData) p).getY() : ((GYROData) p).getY());
        }
        smooth(counts, tempY);
        counts.clear();
        for (Object p : list) {
            counts.add(acc ? ((ACCData) p).getZ() : ((GYROData) p).getZ());
        }
        smooth(counts, tempZ);
        counts.clear();
        for (int i = 0; i < list.size(); i++) {
            result.add(acc ? new ACCData(((ACCData) list.get(i)).getTimestamp()
                    , tempX.get(i)
                    , tempY.get(i)
                    , tempX.get(i)) :
                    new GYROData(((GYROData) list.get(i)).getTimestamp()
                            , tempX.get(i)
                            , tempY.get(i)
                            , tempX.get(i)));
        }
        return result;
    }

    //    @Override
    private void smooth(List<Float> list, List<Float> result) {
        for (int i = 0; i < list.size(); i++) {
            if (i < 3 || i > list.size() - 3) {
                result.add(list.get(i));
            } else {
                Float t = (-3 * list.get(i - 2) + 12 * list.get(i - 1) + 17 * list.get(i) + 12 * list.get(i + 1) - 3 * list.get(i + 2)) / 35;
                result.add(t);
            }
        }
    }
}
