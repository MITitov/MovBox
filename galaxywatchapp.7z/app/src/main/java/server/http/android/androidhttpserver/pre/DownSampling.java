package server.http.android.androidhttpserver.pre;

import java.util.List;

import server.http.android.androidhttpserver.data.ACCData;

public interface DownSampling<T extends ACCData> {
//    List<HRMData> downSampleHRM(List<HRMData> data);

    List<T> downSampleAG(List<T> data);
}
