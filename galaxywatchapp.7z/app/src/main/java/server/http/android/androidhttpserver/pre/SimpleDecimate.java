package server.http.android.androidhttpserver.pre;

import java.util.ArrayList;
import java.util.List;

import server.http.android.androidhttpserver.data.ACCData;
import server.http.android.androidhttpserver.data.GYROData;
import server.http.android.androidhttpserver.data.HRMData;

public class SimpleDecimate implements DownSampling {
    private int coeffACC = 10;
    private int coeffHRM = 10;

    public SimpleDecimate() {
    }

    public SimpleDecimate(int coeffACC, int coeffHRM) {
        this.coeffACC = coeffACC;
        this.coeffHRM = coeffHRM;
    }

    //    @Override
    public List<HRMData> downSampleHRM(List<HRMData> data) {
        List<HRMData> result = new ArrayList<>();
        for (int i = 0; i < data.size(); i++) {
            if (i % coeffHRM == 0) {
                result.add(new HRMData(data.get(i).getTimestamp(), data.get(i).getBpm()));
            }
        }
        return result;
    }

    @Override
    public List downSampleAG(List data) {
        boolean acc = !(data.get(0) instanceof GYROData);
        List result = new ArrayList();
        for (int i = 0; i < data.size(); i++) {
            if (i % coeffACC == 0) {
                if (acc) {
                    result.add(new ACCData(((ACCData) data.get(i)).getTimestamp()
                            , ((ACCData) data.get(i)).getX()
                            , ((ACCData) data.get(i)).getY()
                            , ((ACCData) data.get(i)).getZ()));
                } else {
                    result.add(new GYROData(((GYROData) data.get(i)).getTimestamp()
                            , ((GYROData) data.get(i)).getX()
                            , ((GYROData) data.get(i)).getY()
                            , ((GYROData) data.get(i)).getZ()));
                }
            }
        }
        return result;
    }
}
