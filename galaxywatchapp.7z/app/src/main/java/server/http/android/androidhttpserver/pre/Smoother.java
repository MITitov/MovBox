package server.http.android.androidhttpserver.pre;

import java.util.List;

import server.http.android.androidhttpserver.data.ACCData;

public interface Smoother<T extends ACCData> {

//    public List<HRMData> smoothHRM(List<HRMData> list);

    public List<T> smoothAG(List<T> list);

//    void smooth(List<Float> list, List<Float> result);
}
