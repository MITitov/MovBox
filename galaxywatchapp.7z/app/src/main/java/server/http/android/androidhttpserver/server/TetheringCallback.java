package server.http.android.androidhttpserver.server;

import android.net.ConnectivityManager;

public abstract class TetheringCallback extends ConnectivityManager.NetworkCallback {
    /**
     * Called when tethering has been successfully started.
     */
    public abstract void onTetheringStarted();

    /**
     * Called when starting tethering failed.
     */
    public abstract void onTetheringFailed();

}
