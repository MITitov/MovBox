package server.http.android.androidhttpserver.data;

import androidx.room.Entity;
import androidx.room.ForeignKey;

import static androidx.room.ForeignKey.CASCADE;

@Entity(foreignKeys = @ForeignKey(entity = Sequence.class,
        parentColumns = "id",
        childColumns = "seq_id",
        onDelete = CASCADE))
public class GYROData extends ACCData {

    public GYROData() {
    }

    public GYROData(long time, float x, float y, float z) {
        super(time, x, y, z);
    }
}
