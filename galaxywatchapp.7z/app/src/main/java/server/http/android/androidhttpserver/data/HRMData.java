package server.http.android.androidhttpserver.data;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import static androidx.room.ForeignKey.CASCADE;

@Entity(foreignKeys = @ForeignKey(entity = Sequence.class,
        parentColumns = "id",
        childColumns = "seq_id",
        onDelete = CASCADE))
public class HRMData extends AbstractData {
    @PrimaryKey(autoGenerate = true)
    private long id;

    private float bpm;
    private long seq_id;

    public HRMData() {
    }

    public HRMData(long time, float bpm) {
        this.id = 0;
        this.timestamp = time;
        this.bpm = bpm;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getSeq_id() {
        return seq_id;
    }

    public void setSeq_id(long seq_id) {
        this.seq_id = seq_id;
    }

    public void setBpm(float bpm) {
        this.bpm = bpm;
    }

    public float getBpm() {
        return bpm;
    }
}
