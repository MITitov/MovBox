package server.http.android.androidhttpserver.data;

import android.util.Log;

import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineDataSet;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import server.http.android.androidhttpserver.MainActivity;

public class AGDataSet<T extends ACCData> {
    String name;
    List<T> data;

    public AGDataSet(String name, List<T> data) {
        this.name = name;
        this.data = data;
    }

    public AGDataSet(String name, BufferedReader br, long millis) throws IOException {
        this.name = name;
        boolean acc = name.contains("Acc");
        String st;
        data = new ArrayList<>();
        boolean timeRead = false;
        long initTime = 0;
        while ((st = br.readLine()) != null) {
            String[] value = st.split(", ");
            if (!timeRead) {
                timeRead = true;
                initTime = Long.valueOf(value[0]);
            }
            if (acc) {
//                T d = new ACCData();
                data.add((T) new ACCData(millis + Long.valueOf(value[0]) - initTime,
                        Float.valueOf(value[2].replace(",", ".")),
                        Float.valueOf(value[3].replace(",", ".")),
                        Float.valueOf(value[4].replace(",", "."))));
            } else {
                data.add((T) new GYROData(millis + Long.valueOf(value[0]) - initTime,
                        Float.valueOf(value[2].replace(",", ".")),
                        Float.valueOf(value[3].replace(",", ".")),
                        Float.valueOf(value[4].replace(",", "."))));
            }
        }
        Log.d(MainActivity.TAG, String.valueOf(data.size()));
        Log.d(MainActivity.TAG, "finished reading file");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<T> getData() {
        return data;
    }

    public void setData(List<T> data) {
        this.data = data;
    }

    public LineDataSet getXLineDataSet() {
        List<Entry> points = new ArrayList<>();
        for (T d : data) {
            points.add(new Entry(d.getTimestamp(), d.getX()));
        }
        LineDataSet set = new LineDataSet(points, name);
        return set;
    }

    public LineDataSet getYLineDataSet() {
        List<Entry> points = new ArrayList<>();
        for (T d : data) {
            points.add(new Entry(d.getTimestamp(), d.getY()));
        }
        LineDataSet set = new LineDataSet(points, name);
        return set;
    }

    public LineDataSet getZLineDataSet() {
        List<Entry> points = new ArrayList<>();
        for (T d : data) {
            points.add(new Entry(d.getTimestamp(), d.getZ()));
        }
        LineDataSet set = new LineDataSet(points, name);
        return set;
    }

    public LineDataSet getXNLineDataSet() {
        List<Entry> points = new ArrayList<>();
        for (T d : data) {
            points.add(new Entry(d.getTimestamp(), d.getXn()));
        }
        LineDataSet set = new LineDataSet(points, name);
        return set;
    }

    public LineDataSet getYNLineDataSet() {
        List<Entry> points = new ArrayList<>();
        for (T d : data) {
            points.add(new Entry(d.getTimestamp(), d.getYn()));
        }
        LineDataSet set = new LineDataSet(points, name);
        return set;
    }

    public LineDataSet getZNLineDataSet() {
        List<Entry> points = new ArrayList<>();
        for (T d : data) {
            points.add(new Entry(d.getTimestamp(), d.getZn()));
        }
        LineDataSet set = new LineDataSet(points, name);
        return set;
    }

    public LineDataSet getMLineDataSet() {
        List<Entry> points = new ArrayList<>();
        for (T d : data) {
            points.add(new Entry(d.getTimestamp(), d.getMagn()));
        }
        LineDataSet set = new LineDataSet(points, name);
        return set;
    }
}
