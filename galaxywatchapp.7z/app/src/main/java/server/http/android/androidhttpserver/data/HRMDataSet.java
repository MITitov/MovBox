package server.http.android.androidhttpserver.data;

import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineDataSet;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HRMDataSet {
    String name;
    List<HRMData> data;

    public HRMDataSet(String name, List<HRMData> data) {
        this.name = name;
        this.data = data;
    }

    public HRMDataSet(String name, BufferedReader br, long millis) throws IOException {
        this.name = name;
        String st;
        data = new ArrayList<>();
        boolean timeRead = false;
        long initTime = 0;
        while ((st = br.readLine()) != null) {
            String[] value = st.split(",");
            if (!timeRead) {
                timeRead = true;
                initTime = Long.valueOf(value[0]);
            }
            data.add(new HRMData(millis + Long.valueOf(value[0]) - initTime,
                    Float.valueOf(value[3].replace(",", "."))));
        }
    }

    public List<HRMData> getData() {
        return data;
    }

    public void setData(List<HRMData> data) {
        this.data = data;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LineDataSet getHRMLineDataSet() {
        List<Entry> points = new ArrayList<>();
        for (HRMData d : data) {
            points.add(new Entry(d.getTimestamp(), d.getBpm()));
        }
        LineDataSet set = new LineDataSet(points, name);
        return set;
    }
}
