package server.http.android.androidhttpserver.features;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

import java.util.HashMap;
import java.util.List;

public class Feature {

    private float mean;
    private float standart_deviation;
    private float skewness;
    private float kurtosis;
    private float abs_energy;
    private float minimum;
    private float median;
    private float maximum;
    private float mean_abs_change;
    private HashMap<Float,Integer> number_peaks;

    public Feature(List<Float> input) {
//        float[] temp = new float[]{};
        DescriptiveStatistics stat = new DescriptiveStatistics();
        for (double v : input) {
            stat.addValue(v);
        }
        mean = (float)stat.getMean();
        standart_deviation = (float) stat.getStandardDeviation();
        skewness = (float) stat.getSkewness();
        kurtosis = (float) stat.getKurtosis();
        abs_energy = 0f;//////////////////
        minimum = (float) stat.getMin();
        median = (float) stat.getPercentile(50);
        maximum = (float) stat.getMax();
        mean_abs_change = 0f;////////////////
    }

    public float getMean() {
        return mean;
    }

    public float getStandart_deviation() {
        return standart_deviation;
    }

    public float getSkewness() {
        return skewness;
    }

    public float getKurtosis() {
        return kurtosis;
    }

    public float getAbs_energy() {
        return abs_energy;
    }

    public float getMinimum() {
        return minimum;
    }

    public float getMedian() {
        return median;
    }

    public float getMaximum() {
        return maximum;
    }

    public float getMean_abs_change() {
        return mean_abs_change;
    }

    public HashMap<Float, Integer> getNumber_peaks() {
        return number_peaks;
    }
}
