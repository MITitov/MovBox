package server.http.android.androidhttpserver;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import server.http.android.androidhttpserver.data.AGDataSet;
import server.http.android.androidhttpserver.data.HRMDataSet;
import server.http.android.androidhttpserver.pre.SGSmoother;
import server.http.android.androidhttpserver.pre.SimpleDecimate;

import static server.http.android.androidhttpserver.MainActivity.CHECKED;
import static server.http.android.androidhttpserver.MainActivity.PATH;

public class ShowGraphActivity extends AppCompatActivity {

    private LineChart chart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences sPref = getSharedPreferences(MainActivity.TAG, MODE_PRIVATE);
        setContentView(R.layout.activity_show_graph);
        LineChart chart = (LineChart) findViewById(R.id.chart);
        Random random = new Random();
        File checkedDir = new File(PATH + CHECKED);
        try {
            if (checkedDir.exists()) {
                List<Entry> data = new ArrayList<>();
//                File file = checkedDir.listFiles()[random.nextInt(checkedDir.listFiles().length)];
                File file = checkedDir.listFiles()[0];
                BufferedReader br = new BufferedReader(new FileReader(file));
                String st = br.readLine();
                LineDataSet lineDataSet;
                LineDataSet smoothedLineDataSet;
                LineDataSet smdecLineDataSet;
                if (file.getName().contains("HRM")) {
//                    HRMDataSet
                    HRMDataSet dataSet = new HRMDataSet(file.getName(), br, 0);
                    lineDataSet = dataSet.getHRMLineDataSet();
                    smoothedLineDataSet = dataSet.getHRMLineDataSet();
                    smdecLineDataSet = dataSet.getHRMLineDataSet();
                } else {
                    AGDataSet dataSet = new AGDataSet(file.getName(), br, 0);
                    SGSmoother smoother = new SGSmoother();
                    SimpleDecimate sd = new SimpleDecimate(Integer.valueOf(sPref.getString(MainActivity.ACC_COEFF, "10"))
                            , Integer.valueOf(sPref.getString(MainActivity.HRM_COEFF, "10")));
                    smoothedLineDataSet = new AGDataSet(dataSet.getName(), smoother.smoothAG(dataSet.getData())).getXLineDataSet();
                    smdecLineDataSet = new AGDataSet(dataSet.getName(), sd.downSampleAG(smoother.smoothAG(dataSet.getData()))).getXLineDataSet();
                    lineDataSet = dataSet.getXLineDataSet();
                }
                ArrayList<ILineDataSet> dataSets = new ArrayList<>();
                lineDataSet.setColor(Color.parseColor("#ffffff04"));
                smoothedLineDataSet.setColor(Color.parseColor("#ff00ff04"));
                smdecLineDataSet.setColor(Color.parseColor("#ffff0004"));
                LineData lineData = new LineData();
                lineData.addDataSet(lineDataSet);
                LineData lineDataS = new LineData();
                lineDataS.addDataSet(smoothedLineDataSet);
                LineData lineDataSD = new LineData();
                lineDataSD.addDataSet(smdecLineDataSet);

                dataSets.add(lineDataSet);
                dataSets.add(smoothedLineDataSet);
                dataSets.add(smdecLineDataSet);
//                chart.setData(lineData);
//                chart.setData(lineDataS);
//                chart.setData(lineDataSD);
                LineData total = new LineData(dataSets);
                chart.setData(total);
                chart.invalidate();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
