package server.http.android.androidhttpserver;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import ml.dmlc.xgboost4j.java.XGBoostError;
import server.http.android.androidhttpserver.data.ACCData;
import server.http.android.androidhttpserver.data.AGDataSet;
import server.http.android.androidhttpserver.data.AppDatabase;
import server.http.android.androidhttpserver.data.GYROData;
import server.http.android.androidhttpserver.data.HRMData;
import server.http.android.androidhttpserver.data.HRMDataSet;
import server.http.android.androidhttpserver.data.Sequence;
import server.http.android.androidhttpserver.pre.SGSmoother;
import server.http.android.androidhttpserver.pre.SimpleDecimate;
import server.http.android.androidhttpserver.server.MyServer;

//import android.support.v4.app.ActivityCompat;
//import android.support.v7.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    static {
        Method[] m = WifiManager.class.getDeclaredMethods();
        for (Method t : m) {
            if (t.getName().contains("getWifiApState")) {
                getWifiApState = t;
            }
            if (t.getName().contains("getWifiApConfiguration")) {
                getWifiApConfiguration = t;
            }
            if (t.getName().contains("isWifiApBlocked")) {
                isWifiApBlocked = t;
            }
            if (t.getName().contains("isWifiApEnabled")) {
                isWifiApEnabled = t;
            }
            if (t.getName().contains("setWifiApEnabled")) {
                setWifiApEnabled = t;
            }
            if (t.getName().contains("getWifiApTimeOut")) {
                getWifiApTimeOut = t;
            }
        }
    }

    public static final String HRM_COEFF = "HRMDownSampleCoeff";
    public static final String CHECKED = "/checked/";
    public static final String HRM_HEAD = "Timestamp, Interval, x, y, z";
    public static final String ACC_HEAD = "Timestamp, date, flag, bpm, rri";
    public static final String ACC_COEFF = "ACCDownSampleCoeff";
    public static final String TAG = "WatchDemo";
    public static String PATH = "";
    boolean isHotspotEnabled = false;
    private MyServer server;
    private static Method getWifiApState;
    private static Method getWifiApConfiguration;
    private static Method isWifiApBlocked;
    private static Method isWifiApEnabled;
    private static Method setWifiApEnabled;
    private static Method getWifiApTimeOut;
    Button connectButton, statusButton, b3, b4;
    public static Handler handler;
    private WifiManager.LocalOnlyHotspotReservation mReservation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        PATH = this.getFilesDir().getPath() + "/";
        setContentView(R.layout.activity_main);
        connectButton = findViewById(R.id.button);
        statusButton = findViewById(R.id.button2);
        handler = new MyHandler(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (server == null) {
            server = MyServer.getInstance();
            Toast.makeText(this, "Server started ", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
//        if(server != null) {
//            server.stop();
//        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        server.stop();
    }

    public void connectWatch(View v) {
        Method method;
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        try {
            method = getWifiApState;
            Integer result = (Integer) method.invoke(wifiManager);
            isHotspotEnabled = result == 13;
            statusButton.setBackgroundColor(isHotspotEnabled ? Color.parseColor("#ffd9ff04") : Color.parseColor("#ffaaaaaa"));
//            WifiConfiguration config = (WifiConfiguration) getWifiApConfiguration.invoke(wifiManager);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
//turnOffHotspot();
//        turnOnHotspot();
        //wifiManager.getWifiApState();

    }

    public void showGraph(View v) {
        Intent intent = new Intent(this, ShowGraphActivity.class);
        startActivity(intent);
    }

    public void showAccGraph(View v) {
        Intent intent = new Intent(this, AccGraphActivity.class);
        startActivity(intent);
    }

    public void clearDB(View v) {
        AppDatabase db = AppDatabase.getInstance(getApplication());
        db.clearAllTables();
        Log.d(TAG, "All db tables cleared");
    }

    public void calculate(View v) throws IOException, XGBoostError {
        String[] args = {PATH};
        BoostFromPrediction.main(args);
//        BasicWalkThrough.main(null);
    }
    @Deprecated
    private void turnOnHotspot() {
        if (!isLocationPermissionEnable()) {
            return;
        }
        final WifiManager manager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        if (manager != null) {
            // Don't start when it started (existed)
            manager.startLocalOnlyHotspot(new WifiManager.LocalOnlyHotspotCallback() {

                @Override
                public void onStarted(WifiManager.LocalOnlyHotspotReservation reservation) {
                    reservation.getWifiConfiguration().preSharedKey = "";
                    reservation.getWifiConfiguration().SSID = "AndroidShare";
                    super.onStarted(reservation);
                    Log.d(TAG, "Wifi Hotspot is on now");
                    mReservation = reservation;
                    isHotspotEnabled = true;
                }

                @Override
                public void onStopped() {
                    super.onStopped();
                    Log.d(TAG, "onStopped: ");
                    isHotspotEnabled = false;
                }

                @Override
                public void onFailed(int reason) {
                    super.onFailed(reason);
                    if (reason == WifiManager.LocalOnlyHotspotCallback.ERROR_INCOMPATIBLE_MODE) {
                        Log.d(TAG, "onFailed: ERROR_INCOMPATIBLE_MODE");
                    }
                    if (reason == WifiManager.LocalOnlyHotspotCallback.ERROR_GENERIC) {
                        Log.d(TAG, "onFailed: ERROR_GENERIC");
                    }
                    if (reason == WifiManager.LocalOnlyHotspotCallback.ERROR_NO_CHANNEL) {
                        Log.d(TAG, "onFailed: ERROR_NO_CHANNEL");
                    }
                    if (reason == WifiManager.LocalOnlyHotspotCallback.ERROR_TETHERING_DISALLOWED) {
                        Log.d(TAG, "onFailed: ERROR_TETHERING_DISALLOWED");
                    }
                    isHotspotEnabled = false;
                }
            }, new Handler());
        }
    }

    @Deprecated
    private void turnOffHotspot() {
        if (!isLocationPermissionEnable()) {
            return;
        }
        if (mReservation != null) {
            mReservation.close();
            isHotspotEnabled = false;
        }
    }

    @Deprecated
    private boolean isLocationPermissionEnable() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 2);
            return false;
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 2);
            return false;
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CHANGE_WIFI_STATE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CHANGE_WIFI_STATE}, 2);
            return false;
        }
        return true;
    }

    public void checkFilesForErrors(View v) {
        SharedPreferences sPref = PreferenceManager.getDefaultSharedPreferences(this);
        boolean errorCheck = sPref.getBoolean("errorChecking", true);
        if (errorCheck) {
            Log.d(TAG, "File error checking started");
            String s = this.getFilesDir().getPath();
            File dir = new File(PATH);
            File checkedDir = new File(PATH + CHECKED);
            if (!checkedDir.exists()) {
                checkedDir.mkdir();
            }
            if (dir.isDirectory()) {
                for (File file : dir.listFiles()) {
                    if (file.isFile()) {
                        if (file.length() == 0) {
                            file.delete();
                            continue;
                        }
                        long prevStamp = 0;
                        long curStamp = 0;
                        boolean firstLine = true;
                        try {
//                    BufferedReader br = new BufferedReader(new FileReader(file));//better to use it in future
                            Log.d(TAG, "File " + file.getName() + " error checking started");
                            List<String> lines = Files.readAllLines(file.toPath());
                            List<String> checked = checkFile(lines, file.getName());
                            Files.delete(file.toPath());
                            if (!checked.isEmpty()) {
                                File checkedFile = new File(PATH + CHECKED + file.getName());

                                if (!checkedFile.exists()) {
                                    checkedFile.createNewFile();
                                }
                                FileWriter writer = new FileWriter(PATH + CHECKED + file.getName());
                                int size = checked.size();
                                for (int i = 0; i < size; i++) {
                                    String str = checked.get(i);
                                    writer.write(str);
                                    if (i < size - 1)
                                        writer.write("\n");
                                }
                                writer.close();
                                Log.d(TAG, "File " + file.getName() + " after error checking created");
                            }

                        } catch (IOException e) {
                            e.printStackTrace();
                            continue;
                        }
                    }
                }
            }
        } else {
            Log.d(TAG, "File error checking skipped");
        }
        putFilesIntoBase();
    }

    private void putFilesIntoBase() {
        Log.d(TAG, "Sending files to base started");
        SharedPreferences sPref = PreferenceManager.getDefaultSharedPreferences(this);
        SGSmoother smoother = new SGSmoother();
        SimpleDecimate sd = new SimpleDecimate(Integer.valueOf(sPref.getString(MainActivity.ACC_COEFF, "10"))
                , Integer.valueOf(sPref.getString(MainActivity.HRM_COEFF, "10")));
        AppDatabase db = AppDatabase.getInstance(getApplication());
        File checkedDir = new File(PATH + CHECKED);
        try {
            if (checkedDir.exists()) {
                for (File file : checkedDir.listFiles()) {
                    final long seq_id;
//                File file = checkedDir.listFiles()[15];//0 acc//15 gyro
                    String startDate = file.getName().substring(0, 15);
                    Log.d(TAG, "File " + file.getName() + " processing started");
                    Sequence seq = new Sequence();
                    LocalDateTime ldt = LocalDateTime.of(Integer.valueOf(startDate.substring(0, 4)),
                            Integer.valueOf(startDate.substring(4, 6)),
                            Integer.valueOf(startDate.substring(6, 8)),
                            Integer.valueOf(startDate.substring(9, 11)),
                            Integer.valueOf(startDate.substring(11, 13)),
                            Integer.valueOf(startDate.substring(13, 15)));
                    ZonedDateTime zdt = ldt.atZone(ZoneId.of("Europe/Moscow"));
                    long millis = zdt.toInstant().toEpochMilli();
                    //find old or create one
                    Sequence[] oldSeq = db.watchModel().getSequencesByTimestamp(millis);
                    if (oldSeq.length == 1) {
                        seq_id = oldSeq[0].getId();
                    } else {
                        seq.setUserName("TEST");
                        seq.setStartDate(file.getName().substring(0, 15));
                        seq.setTimestamp(millis);
                        seq.setId(0);
                        seq_id = db.watchModel().insertSequence(seq);
                    }
                    BufferedReader br = new BufferedReader(new FileReader(file));
                    String st = br.readLine();
                    if (file.getName().contains("HRM")) {
//                    HRMDataSet
                        HRMDataSet dataSet = new HRMDataSet(file.getName(), br, millis);
//                        dataSet.setData(sd.downSampleHRM(smoother.smoothHRM(dataSet.getData())));
                        for (HRMData data : dataSet.getData()) {
                            data.setSeq_id(seq_id);
                        }
                        db.watchModel().insertHRMList(dataSet.getData());
                    } else {
                        AGDataSet dataSet = new AGDataSet(file.getName(), br, millis);
                        dataSet.setData(sd.downSampleAG(smoother.smoothAG(dataSet.getData())));
                        Log.d(TAG, "Data insertion started");
                        if (file.getName().contains("Accel")) {
//                        dataSet.getData().stream().parallel().forEach(data -> data.setSeq_id(seq_id));
//                        db.watchModel().insertACCData(dataSet.getData().stream().toArray(ACCData[]::new));
                            for (Object data : dataSet.getData()) {
                                ((ACCData) data).setSeq_id(seq_id);
                            }
                            db.watchModel().insertACCList(dataSet.getData());
                        } else {
                            for (Object data : dataSet.getData()) {
                                ((GYROData) data).setSeq_id(seq_id);
                            }
                            db.watchModel().insertGYROList(dataSet.getData());
//                        db.watchModel().insertGYROData(dataSet.getData().stream().toArray(GYROData[]::new));
                        }
                        Log.d(TAG, "Data insertion finished");
                    }
                    Log.d(TAG, "File " + file.getName() + " processing finished");
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<String> checkFile(List<String> lines, String name) {
        List<String> result = new ArrayList<>();
        long prevStamp = 0;
        long curStamp = 0;
        boolean firstLine = true;
        boolean isHRM = name.contains("HRM");

        if (lines.isEmpty())
            return result;
        for (String line : lines) {
            //missing column heading
            if (firstLine) {
                if (!line.startsWith("Timestamp")) {
                    result.add(isHRM ? HRM_HEAD : ACC_HEAD);
                }
                firstLine = false;
            } else {
                curStamp = Long.valueOf(line.substring(0, line.indexOf(",")));
                if (curStamp - prevStamp <= 0) {
                    continue;
                }
                prevStamp = curStamp;
            }
            //extra value or last row
            if (line.split(isHRM ? "," : " ").length != 5) {
                continue;
            }
            result.add(line);
        }
        if (lines.size() < 2) {
            return new ArrayList<>();
        }
        return result;
    }

    public void showMessage(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    static class MyHandler extends Handler {
        WeakReference<MainActivity> wrActivity;

        public MyHandler(MainActivity activity) {
            wrActivity = new WeakReference<MainActivity>(activity);
        }

        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            MainActivity activity = wrActivity.get();
            if (activity != null)
                activity.showMessage(msg.getData().getString("msg", ""));
        }
    }
}
