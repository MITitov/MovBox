package server.http.android.androidhttpserver.server;

import android.os.Bundle;
import android.os.Message;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;

import server.http.android.androidhttpserver.MainActivity;

import static server.http.android.androidhttpserver.MainActivity.PATH;
import static server.http.android.androidhttpserver.MainActivity.TAG;


public class MyServer extends NanoHTTPD {
    private static MyServer INSTANCE = new MyServer();
    private final static int PORT = 5000;//Flask = 5000; Default = 8080
    String fileName = null;

    private MyServer(){
        super(PORT);
        try {
            start();
        System.out.println( "\nRunning! Point your browers to http://localhost:"+PORT+"/ \n" );
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println( "Failed to launch server" );
        }
    }
    public static MyServer getInstance() {
        return INSTANCE;
    }

    @Override
    public Response serve(IHTTPSession session) {
        if (session.getMethod() == Method.GET) {
            fileName = session.getUri().substring(session.getUri().lastIndexOf("/")+1);
            File check = new File(PATH+fileName);
            return newFixedLengthResponse(String.valueOf(check.length()));
//            String msg = "<html><body><h1>Hello server</h1>\n";
//            msg += "<p>We serve " + session.getUri() + " !</p>";
//            return newFixedLengthResponse(msg + "</body></html>\n");
        }
        if (session.getMethod() == Method.POST && session.getUri().equalsIgnoreCase("/upload/")) {
            if (fileName == null) return null;
            Map<String, String> hdrs=session.getHeaders();
            Map<String, String> params=session.getParms();

            Map<String, String> files = new HashMap<String, String>();
            try {
                session.parseBody(files);
                String tmpFileName = files.get("fileN");
                Path origin = Paths.get(tmpFileName);
                Path copy = Paths.get(PATH + fileName);
                Files.move(origin, copy, StandardCopyOption.REPLACE_EXISTING);//was copy
                Log.d(TAG, "File " + fileName + " received");
                Message msg = new Message();
                Bundle bundle = new Bundle();
                bundle.putString("msg", "File " + fileName + " received");
                msg.setData(bundle);
                MainActivity.handler.sendMessage(msg);
//                if (nf.canWrite()) {
//                    boolean success = of.renameTo(nf);
//                    if (success == true) {
//                        // LOG to console
//                        Log.e("FILE_MOVED_TO", p);
//                    } else {
//                        Log.e("FILE_MOVE_ERROR", tmpFileName);
//                    }
//                }
                fileName = null;
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ResponseException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
