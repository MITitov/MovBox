package server.http.android.androidhttpserver.data;

public abstract class AbstractData {
    protected long timestamp;
//    protected long seq_id;

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

//    public long getSeq_id() { return seq_id; }
//
//    public void setSeq_id(long seq_id) { this.seq_id = seq_id; }
}
