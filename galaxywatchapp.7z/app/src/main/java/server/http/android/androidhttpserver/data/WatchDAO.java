package server.http.android.androidhttpserver.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface WatchDAO {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertACCData(ACCData... data);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertACCList(List<ACCData> data);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertGYROData(GYROData... data);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertGYROList(List<GYROData> data);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertHRMList(List<HRMData> data);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertHRMData(HRMData... data);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public long insertSequence(Sequence seq);

    @Query("SELECT * FROM sequence")
    public Sequence[] selectAllSequence();

    @Query("SELECT * FROM accdata")
    public ACCData[] selectAllACCData();

    @Query("SELECT * FROM gyrodata")
    public GYROData[] selectAllGYROData();

    @Query("SELECT * FROM hrmdata")
    public HRMData[] selectAllHRMData();
//    public ACCData[] loadACCData();
//
//    public GYROData[] loadGYROData();
//
//    public HRMData[] loadHRMData();

    @Query("SELECT * FROM accdata WHERE seq_id = :seq_id")
    public ACCData[] getACCDataBySequence(long seq_id);

    @Query("SELECT * FROM sequence WHERE timestamp = :timestamp")
    public Sequence[] getSequencesByTimestamp(long timestamp);

    @Query("DELETE FROM sequence")
    public void deleteAll();

    @Query("SELECT count(*) FROM accdata")
    public int getACCDataCount();

    @Query("SELECT count(*) FROM gyrodata")
    public int getGYRODataCount();

    @Query("SELECT count(*) FROM hrmdata")
    public int getHRMDataCount();

    @Query("SELECT count(*) FROM sequence")
    public int getSequenceDataCount();
}
