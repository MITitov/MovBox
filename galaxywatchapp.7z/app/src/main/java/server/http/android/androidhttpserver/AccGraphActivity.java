package server.http.android.androidhttpserver;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import java.util.ArrayList;
import java.util.Arrays;

import server.http.android.androidhttpserver.data.ACCData;
import server.http.android.androidhttpserver.data.AGDataSet;
import server.http.android.androidhttpserver.data.AppDatabase;
import server.http.android.androidhttpserver.data.Sequence;

public class AccGraphActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences sPref = PreferenceManager.getDefaultSharedPreferences(this);
        setContentView(R.layout.activity_acc_graph);
        LineChart chart = (LineChart) findViewById(R.id.chart);
        AppDatabase db = AppDatabase.getInstance(getApplication());
        //no more needed, done before inserting to base
//        SGSmoother smoother = new SGSmoother();
//        SimpleDecimate sd = new SimpleDecimate(Integer.valueOf(sPref.getString(MainActivity.ACC_COEFF, "10"))
//                , Integer.valueOf(sPref.getString(MainActivity.HRM_COEFF, "10")));
        ArrayList<ILineDataSet> dataSets = new ArrayList<>();
        Sequence[] sequences = db.watchModel().selectAllSequence();

        for (Sequence seq : sequences) {
            long seq_id = seq.getId();
            Log.d(MainActivity.TAG, "Loading seq: " + seq_id + ", " + seq.getStartDate());
            ACCData[] data = db.watchModel().getACCDataBySequence(seq_id);
            Log.d(MainActivity.TAG, "ACC size: " + data.length);
            ArrayList<ACCData> adata = new ArrayList<>(Arrays.asList(data));
            AGDataSet dataSet = new AGDataSet(seq.getStartDate(), adata);
            LineDataSet xLineDataSet = dataSet.getXLineDataSet();
            LineDataSet yLineDataSet = dataSet.getYLineDataSet();
            LineDataSet zLineDataSet = dataSet.getZLineDataSet();
            Log.d(MainActivity.TAG, "0:" + ((ACCData) dataSet.getData().get(0)).getTimestamp());
            Log.d(MainActivity.TAG, "1:" + ((ACCData) dataSet.getData().get(1)).getTimestamp());

            xLineDataSet.setColor(Color.parseColor("#ffff0000"));
            xLineDataSet.setDrawValues(false);
            xLineDataSet.setDrawCircles(false);
            xLineDataSet.setMode(LineDataSet.Mode.LINEAR);
            xLineDataSet.setDrawFilled(false);

//            yLineDataSet = new AGDataSet(dataSet.getName(), smoother.smoothAG(adata)).getXLineDataSet();
//            List<ACCData> t = smoother.smoothAG(adata);
//            zLineDataSet = new AGDataSet(dataSet.getName(), sd.downSampleAG(t)).getXLineDataSet();

            yLineDataSet.setColor(Color.parseColor("#ff00ff00"));
            yLineDataSet.setDrawValues(false);
            yLineDataSet.setDrawCircles(false);
            yLineDataSet.setMode(LineDataSet.Mode.LINEAR);
            yLineDataSet.setDrawFilled(false);
//
//            zLineDataSet.setColor(Color.parseColor("#ff0000ff"));
//            zLineDataSet.setDrawValues(false);
//            zLineDataSet.setDrawCircles(false);
//            zLineDataSet.setMode(LineDataSet.Mode.LINEAR);
//            zLineDataSet.setDrawFilled(false);

            dataSets.add(xLineDataSet);
            dataSets.add(yLineDataSet);
//            dataSets.add(zLineDataSet);
        }
        LineData total = new LineData(dataSets);
        chart.setDrawMarkers(false);
        chart.setData(total);
        chart.invalidate();
    }
}
