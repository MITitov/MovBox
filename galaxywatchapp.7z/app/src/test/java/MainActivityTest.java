//import com.google.common.truth.Truth.assertThat;

import android.content.res.AssetManager;

import org.junit.Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import server.http.android.androidhttpserver.MainActivity;

import static org.junit.Assert.assertEquals;

public class MainActivityTest {
    String[] files = {"20190127-114640_HRM_CONTINUES.txt",
    "20190130-073244_Accel_CONTINUES.txt",
            "20190204-060819_Accel_CONTINUES.txt",
            "20190205-115352_Accel_CONTINUES.txt",
            "20190206-165236_GYRO_CONTINUES.txt",
            "20190207-115458_Accel_CONTINUES.txt"};
    @Test
    public void FileErrorsTest() {

        List<Boolean> result = new ArrayList<>();
        for (String file : files) {
            List<String> lines = new ArrayList<>();
            Scanner sc = new Scanner(this.getClass().getResourceAsStream(file));
            while (sc.hasNextLine())
                lines.add(sc.nextLine());
            List<String> checked = MainActivity.checkFile(lines,file);
            if (checked.size() != lines.size() || lines.size()==0)
                result.add(true);
//            assertEquals(lines.size(),checked.size());
        }
        assertEquals(result.size(),files.length - 1);//115458 - +1 -1 = 0 need to fix it later
    }
}
